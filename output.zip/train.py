'''
    guozhenyuan
    2022-8-5
'''

from re import I
from client import Client
from utils import load_client_data
from yacs.config import CfgNode


if __name__ == '__main__':

    config = CfgNode.load_cfg(open('./config.yaml'))
    all_dl = load_client_data(config.data_sp)
    all_client=[]

    for i in range(1,14):
        client_id = i
        client_name = 'client' + str(i)
        client_cfg = config[client_name]
        client_train_dl = all_dl[i]['train']
        client_val_dl = all_dl[i]['val']
        client_test_dl = all_dl[i]['test']
        client = Client(id=i,config=client_cfg,train_dl=client_train_dl,val_dl=client_val_dl,test_dl=client_test_dl)
        all_client.append(client)
    
    for client in all_client:
        client.update()


