'''
    by:GuoZhenyuan
    time: 2022-8-3
'''

import torch
import torch.nn.functional as F

from model import GCN_C,GCN_R

class Client(object):
    def __init__(self,id,config,train_dl,val_dl,test_dl=None):
        self.id = id
        self.round=0
        self.cfg = config

        self.device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        self.model = self.load_model().to(self.device)

        # 加载数据
        self.tra_dl = train_dl
        self.val_dl = val_dl
        self.tes_dl = test_dl
    
        # 定义损失函数
        if self.cfg.task == 'C': # 执行分类任务
            self.criterion = torch.nn.CrossEntropyLoss()
        elif self.cfg.task == 'R':
            self.criterion = torch.nn.MSELoss()
        else:
            print('输入的任务类型有误')
        # 定义优化器
        self.optimizer = torch.optim.Adamax(self.model.parameters(), lr=config.lr)

    def load_model(self):
        if self.cfg.task == 'C':
            model = GCN_C(in_channels=self.cfg.in_channel,out_channels=self.cfg.out_channel,max_depth=self.cfg.max_depth,num_cls=self.cfg.num_cls)
        else:
            model = GCN_R(in_channels=self.cfg.in_channel,out_channels=self.cfg.out_channel,max_depth=self.cfg.max_depth,num_cls=self.cfg.num_cls)
        return model


    def update(self):
        for e in range(1,self.cfg.ep+1):
            # print('Start Client Update')
            if self.cfg.task == "C":
                self.train_C()
                self.test_C()
            else:
                self.train_R()
                self.test_R()
            self.printInf()
        print('Next')
        return 1

    def train_C(self):
        self.model.train()
        acc = 0 # 分类时候的正确率
        los = 0

        for i, data in enumerate(self.tra_dl):
            self.optimizer.zero_grad()

            data = data.to(self.device)
            out = self.model(data)

            # 计算损失
            label = F.one_hot(data.y,num_classes=2).squeeze(1).float()
            loss = self.criterion(out,label)

            # 反向传播
            loss.backward()
            self.optimizer.step()

            # 计算正确率和损失
            pred = out.argmax(dim=1)
            acc += int((pred == data.y.squeeze(1)).sum())
            los += loss.item()
        acc = acc / len(self.tra_dl.dataset)
        los = los / len(self.tra_dl.dataset)

        self.train_acc,self.train_los = acc,los
        # print('Client:{} Train C loss: {:.5f} acc: {:.5f}'.format(self.id,los,acc))
    
    def train_R(self):
        self.model.train()
        mse = 0

        for i, data in enumerate(self.tra_dl):
            self.optimizer.zero_grad()

            data = data.to(self.device)
            out = self.model(data)

            # 计算损失
            label = data.y
            loss = self.criterion(out,label)

            # 反向传播
            loss.backward()
            self.optimizer.step()

            # 激素啊mse
            mse += loss.item()
        self.trian_mse = mse
        # print('Client:{} Train R MSE:{:.5f}'.format(self.id,mse))

    def test_C(self):
        self.model.eval()
        acc = 0 # 分类时候的正确率
        los = 0

        for i, data in enumerate(self.val_dl):

            data = data.to(self.device)
            out = self.model(data)

            # 计算损失
            label = F.one_hot(data.y,num_classes=2).squeeze(1).float()
            loss = self.criterion(out,label)

            # 计算正确率和损失
            pred = out.argmax(dim=1)
            acc += int((pred == data.y.squeeze(1)).sum())
            los += loss.item()
        acc = acc / len(self.val_dl.dataset)
        los = los / len(self.val_dl.dataset)
        self.val_acc,self.val_loss = acc,los
        # print('Client:{} Val C loss: {:.5f} acc: {:.5f}'.format(self.id,los,acc))
    
    def test_R(self):
        self.model.eval()
        mse = 0

        for i, data in enumerate(self.val_dl):

            data = data.to(self.device)
            out = self.model(data)

            # 计算损失
            label = data.y
            loss = self.criterion(out,label)

            # 激素啊mse
            mse += loss.item()
        
        self.val_mse=mse
        # print('Client:{} Val R MSE:{:.5f}'.format(self.id,mse))
    
    def printInf(self):
        if self.cfg.task == "C":
            print('Client: {:2d} \t Task: C \t Train ACC: {:.5f} \t Tran Loss: {:.5f} \t Val ACC: {:.5f} \t Val Loss: {:.5f}'.format(self.id,self.train_acc,self.train_los,self.val_acc,self.val_loss))
        else:
            print('Client: {:2d} \t Task: R \t Train MSE: {:.5f} \t Val MSE: {:.5f} '.format(self.id,self.trian_mse,self.val_mse))

    def result(self):
        pass


